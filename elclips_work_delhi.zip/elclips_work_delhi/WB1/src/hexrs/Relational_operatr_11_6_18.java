package hexrs;

public class Relational_operatr_11_6_18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	System.out.println(10>86);
	System.out.println(10<86);
	System.out.println(10>=86);
	System.out.println(10<=86);
	System.out.println(10==86);
	Relational_operatr_11_6_18 rss=new Relational_operatr_11_6_18();
	show();
	rss.shoow();	
	}
static boolean show()
{
	boolean b1= true;
	if(b1==true)
	{
		System.out.println("if run");
	}
	return b1;
}
public void shoow()
{
	boolean b2=false;
	if(b2=false)
	{
		System.out.println("else run");
	}
}

}
