package hexrs;

public class Boolean_litrals_7_6_18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
boolean b1=true;
boolean b2=false;
int i=0;

do{	++i;
		if(b1==true)
		{
			System.out.println("wellcome hextrs");
			boolean b3=false;
			b3=b1;
			b1=b2;
			b2=b3;
					
		}
		else
		{
			System.out.println("swap function work");
			b1=true;
			b2=false;
		}
	}while(i<5);
}
}
