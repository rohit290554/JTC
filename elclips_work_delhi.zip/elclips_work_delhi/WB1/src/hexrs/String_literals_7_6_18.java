package hexrs;

public class String_literals_7_6_18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1=",";
String s2="dfiuhfiuhfiudh33qr%";
String s3=(s1+s2);//addition of string
String s4=(s1+s1);
System.out.println(s1);
System.out.println(s2);
System.out.println(s3);
System.out.println(s4);
	}

	
}
