package hexrs;

public class Type_casting_10_6_18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=100;
		int b=1000;
		byte bb=(byte) ((byte)a+b);//byte casting  EXPLICIT CASTINGH
		System.out.println(bb);
	float aa=7374.83484f;
	int aaa=(int)aa;//float to int casting EXPLICIT CASTING
	int r=(int) +aa;
	System.out.println(aa);
	System.out.println(aaa);
	System.out.println(r);
	int bbb=1000;
	byte bbbb=(byte)bbb;//int to byte EXPLICIT
	System.out.println(bbbb);
	
	}

}
