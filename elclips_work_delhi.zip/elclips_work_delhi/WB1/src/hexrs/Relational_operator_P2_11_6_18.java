package hexrs;

public class Relational_operator_P2_11_6_18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(20/2==40/4);
		//System.out.println(0/0); java.lang.ArithmeticException: /zero error
		System.out.println(Float.NaN==Float.NaN);
		int r=0;
		System.out.println("x="+r+" ab hmse na hoga "+r);
	}

}
