package hexrs;

public class Integral_literals_7_6_18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i1=24234242;
int i2=2147483647;
long i3=2147483648l;
System.out.println(i1);
System.out.println(i2);
System.out.println(i3);
System.out.println("\tbyte value\n");
System.out.println(Byte.MAX_VALUE);//byte max value 
System.out.println(Byte.MIN_VALUE);//byte min value
System.out.println("\tinteger value\t");
System.out.println(Integer.MAX_VALUE);//integer max value
System.out.println(Integer.MIN_VALUE);//integer min value
System.out.println("\tSort value\t");
System.out.println(Short.MAX_VALUE);//short max value
System.out.println(Short.MIN_VALUE);//short min value
System.out.println("\tlong value\n");
System.out.println(Long.MAX_VALUE);//long max value
System.out.println(Long.MIN_VALUE);//long min value
System.out.println("\tfloat value\t");
System.out.println(Float.MAX_VALUE);//float max value
System.out.println(Float.MIN_VALUE);//float min value
	}

}
