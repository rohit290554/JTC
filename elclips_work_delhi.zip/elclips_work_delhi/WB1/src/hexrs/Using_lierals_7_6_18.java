package hexrs;

public class Using_lierals_7_6_18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ab=74374;
		String bin=Integer.toString(ab);
		String oct=Integer.toOctalString(ab);
		String hx=Integer.toHexString(ab);
		System.out.println(bin);				
		System.out.println(oct);
		System.out.println(hx);
		System.out.printf("\n %d %o %x",ab,ab,ab);
		System.out.println();
		System.out.println(Math.PI);
		System.out.println(Math.E);
		
		
	}

}
