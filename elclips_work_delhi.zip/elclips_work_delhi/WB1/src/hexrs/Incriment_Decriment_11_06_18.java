package hexrs;

public class Incriment_Decriment_11_06_18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i1=100;
System.out.println("Incriment");//post incriment   ASSIGN THEN UPDATE
for(int i = 0;i<10;i++)
{
	System.out.println(i1++);
}
System.out.println("Decriment");
for(int i = 0;i<10;i++)
{
	System.out.println(i1--);
}
int i2=++i1;//pre-incriment        UPDATE THEN ASSIGN
System.out.println("\n");
System.out.println(i2);
System.out.println(i1);
	}

}
