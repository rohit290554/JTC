package hexrs;

public class Floating_literals_7_6_18_7_6_18 {
	public static void main(String[] args) {
		double d1=3533.33;
		double d2=446546e3;
		System.out.println(d1);
		System.out.println(d2);
		double d3=3423424d;
		String in=null;
		System.out.println(in);
		
	}

}
