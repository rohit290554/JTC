package hexrs;

public class Logical_operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("------------------LOGICAL NOT------------------------");
		int res=90;
		boolean b1=(res==90);
		boolean b2=!(res==90);
		boolean b3=!b1;
		System.out.println(b1);
		System.out.println(b2);
		System.out.println(b3);
		System.out.println("--------------LOGICAL AND-----------------------");
		int a=14;
		boolean b4=a<16&&a++<4;
		System.out.println(b4);
		int x=224;
		boolean b5=x>16&&x++<444;
		System.out.println(b5);
		System.out.println("--------------LOGICAL OR--------------------");
		int m=14;
		boolean b6=m>16||m++>54;
		System.out.println(b6);
		boolean b7=m<16||m-->4;
		System.out.println(b7);
		
		
	}

}
