package hexrs;

public class Character_literals_7_6_18{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
char ch='a';
char ch1=65;
char ch3='*';
char ch2='\u0022';
//ch5='     ';
//char ch6='\u00cf'
char ch7=(char) -1;
System.out.println(ch);
System.out.println(ch1);
System.out.println(ch3);
System.out.println(ch7);
	}

}
