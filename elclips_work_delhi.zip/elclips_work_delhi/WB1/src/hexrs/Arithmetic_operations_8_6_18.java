package hexrs;

public class Arithmetic_operations_8_6_18{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int aa=46;
		System.out.println(aa);
		int a=+aa;
		System.out.println(a);
		//int b+=aa; not possible
		int b=-aa;
		System.out.println(b);
		int c=- -aa;
		System.out.println(c);
		int d=-(-aa);
		System.out.println(d);
		byte b1=10;
		byte b2=04;
		byte b3=(byte) (b1+b2);
		System.out.println(512145/6987);
		System.out.println(4654*5);
		
		
		
		

	}

}
