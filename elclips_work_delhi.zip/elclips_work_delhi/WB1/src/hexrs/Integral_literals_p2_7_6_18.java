package hexrs;

public class Integral_literals_p2_7_6_18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("\n---OCTAL---");
		byte a=012;
		System.out.println(a);
	//	int b= 09; this is not possible
		int c=555555545;
		System.out.println("\n----------decimal------------------");
		int m=76463;
		System.out.println(m);
		byte b2=123;
		System.out.println("\n---------------hexadecimal---------------");
		int r=0x656;
		int rr=0xfe;
		System.out.println(r);
		System.out.println(rr);
		

	}

}
