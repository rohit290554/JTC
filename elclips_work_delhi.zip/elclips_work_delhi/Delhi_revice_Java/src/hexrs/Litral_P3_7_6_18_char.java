package hexrs;

public class Litral_P3_7_6_18_char {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char i1= 1234;         
		char i2 = (char) 1010101d;     
		char i3 = 101;     
		char i4 = 'a';   
		char i5 = 'a'+'b';   
		char i6 = 'a';    
		char i7 = 'b'+'v'+'A';   
		char i8 = 'B';    
		char i9 = 'x'+'A'+'B'+'C'+'D'+'E'+'F';   
		
		System.out.println(i1);
		System.out.println(i2);
		System.out.println(i3);
		System.out.println(i4);
		System.out.println(i5);
		System.out.println(i6);
		System.out.println(i7);
		System.out.println(i8);
		System.out.println(i9);

	}

}
