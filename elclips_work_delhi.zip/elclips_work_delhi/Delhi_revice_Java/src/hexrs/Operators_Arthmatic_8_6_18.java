package hexrs;
import java.util.Scanner;
public class Operators_Arthmatic_8_6_18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 //plus
		Scanner sc= new Scanner(System.in);
		int n = 0;
		n=sc.nextInt();
		String[] rs = new String[n];
		rs=s
		System.out.println(a);
		
	}

}
