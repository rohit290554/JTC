package hexrs;

public class Litral_P2_7_6_18_float {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float i1= 1.234f;         //decimal//
		float i2 = 10101f;     //decimal//
		float i3 = 1010000;     //decimal//
		double i4 = 999999999f;   //decimal//
		float i5 = 0101010;   //Oct//
		float i6 = 013320;    //Oct//
		float i7 = 0b10101;   //binary//
		float i8 = 0x010B;    //hex//
		float i9 = 0xADEF;    //hex//
		
		System.out.println(i1);
		System.out.println(i2);
		System.out.println(i3);
		System.out.println(i4);
		System.out.println(i5);
		System.out.println(i6);
		System.out.println(i7);
		System.out.println(i8);
		System.out.println(i9);
	}

}
