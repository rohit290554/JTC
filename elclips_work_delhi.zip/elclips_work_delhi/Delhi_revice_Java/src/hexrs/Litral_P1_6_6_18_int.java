package hexrs;

public class Litral_P1_6_6_18_int{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int i1= 1234;         //decimal//
			int i2 = 1010101;     //decimal//
			int i3 = 1010000;     //decimal//
			int i4 = 999999999;   //decimal//
			int i5 = 010101010;   //Oct//
			int i6 = 01324320;    //Oct//
			int i7 = 0b1010101;   //binary//
			int i8 = 0x0101AB;    //hex//
			int i9 = 0xABCDEF;    //hex//
			
			System.out.println(i1);
			System.out.println(i2);
			System.out.println(i3);
			System.out.println(i4);
			System.out.println(i5);
			System.out.println(i6);
			System.out.println(i7);
			System.out.println(i8);
			System.out.println(i9);
	}		

}
