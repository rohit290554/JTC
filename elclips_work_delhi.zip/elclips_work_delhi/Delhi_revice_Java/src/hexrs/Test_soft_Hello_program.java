package hexrs;

public class Test_soft_Hello_program {

	public static void main(String[] args) {
		/* char ch '\u00021654871645165651658764154684168765489761657846578945676846578946578974';
		 * system.out.println(ch);
		 */
	}
}
